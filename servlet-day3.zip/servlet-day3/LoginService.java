package com.cdac.service;

public interface LoginService {

	public boolean isValidUser(String username, String password);
}
