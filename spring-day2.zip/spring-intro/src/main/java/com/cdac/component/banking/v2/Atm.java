package com.cdac.component.banking.v2;

public interface Atm {

	public void withdraw(int acno, double amount);
}
