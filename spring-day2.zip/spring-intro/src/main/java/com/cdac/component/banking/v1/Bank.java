package com.cdac.component.banking.v1;

public interface Bank {

	public void communicate(int atmId, String action);
}
