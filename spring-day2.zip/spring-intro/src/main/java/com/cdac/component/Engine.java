package com.cdac.component;

import org.springframework.stereotype.Component;

@Component
public class Engine {

	public void ignite() {
		System.out.println("vroom vroom..");
	}
}
