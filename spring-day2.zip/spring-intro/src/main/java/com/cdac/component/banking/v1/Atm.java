package com.cdac.component.banking.v1;

public interface Atm {

	public void withdraw(int acno, double amount);
}
